<?php
session_start();


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../vendor/phpmailer/phpmailer/src/Exception.php';
require '../vendor/phpmailer/phpmailer/src/PHPMailer.php';
require '../vendor/phpmailer/phpmailer/src/SMTP.php';

require '../vendor/autoload.php';
function redirect($url,$message)
{
    header('location: ' . $url);
    $_SESSION['message'] = $message;
}
function topheading($heading)
{
    $_SESSION['topheading'] = $heading;
}

$ipinfo_response = file_get_contents('https://ipinfo.io/json');
if ($ipinfo_response !== false) {

    $ipinfo_data = json_decode($ipinfo_response, true);

    $ip_address = $ipinfo_data['ip'];
    $city = $ipinfo_data['city'];
    $country = $ipinfo_data['country'];

    if (isset($_POST['submit_btn'])) {
        $mail = new PHPMailer();

        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $subject = $_POST['subject'];
        $message = $_POST['message'];

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'adnankaka.786110@gmail.com';
        $mail->Password = 'xcvk pfwy wwkf bfbo';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;
        $mail->setFrom('adnankaka.786110@gmail.com', $_POST['name']);

        $recipient = 'info@onlyfansmarketinghub.com';
        $mail->addAddress($recipient);

        $mail->isHTML(true);

        $mail->Subject = $subject;

        $mail->Body = 'Name: '. $name. '<br>'. 
                'Email: '. $email. '<br>'. 
                'Phone: '. $phone. '<br>'. 
                'Message: '. $message. '<br>'.
                'IP Address: '. $ip_address. '<br>'.
                'City: '. $city. '<br>'.
                'Country: '. $country. '<br>'.
                'From: '. $email;

        $mail->AltBody = 'Name: '. $name. '\n'. 
                'Email: '. $email. '\n'. 
                'Phone: '. $phone. '\n'. 
                'Message: '. $message. '\n'.
                'IP Address: '. $ip_address. '<br>'.
                'City: '. $city. '<br>'.
                'Country: '. $country. '<br>'.
                'From: '. $email;


        $mail->send();
        redirect("../index.php", "Thank you for submitting your query to <span class=\"text-primary\">OnlyFans Marketing Hub</span>.<br> 
        One of our consultants will be in touch with you shortly to discuss next steps.");
        topheading('Thankyou 😊');
    } else {
        redirect("../index.php","Something Went Wrong: ".$mail->ErrorInfo);
        topheading('Oops ‼️');
    }
} else {
    echo "Failed to retrieve IP information.";
}
