<div class="container">
    <div class="service-main col-md-12 mt-5">
        <div class="content">
            <div class="text">
                <h1><?php echo $serviceName; ?></h1>
                <div class="breadcrumb">
                    <a href="index.php">Home</a>
                    <span class="mx-2">/</span>
                    <span class="breadcrumb-item">Services</span>
                </div>
            </div>
        </div>
    </div>
</div>